//Student interface - main.js


//This function displays hidden elements for the Announcements page
function toggleDisplayAnn(x, z) {
    var x = document.getElementById(x);     // the folder button
    var z = document.getElementById(z);     // the folder display
    var box = ["annbox1", "annbox2", "annbox3"];
    var display = ["ann1", "ann2", "ann3"];

    for (let i = 0; i < box.length; i++) { // hide all folders that are not selected
        document.getElementById(box[i]).style.background = "none";
        document.getElementById(display[i]).style.display = "none";
    }
    x.style.background = "#D5F5CD";
    z.style.display = "block";
}


//This function displays hidden elements for the Resources page
function toggleDisplayRes(x, z) {
    var x = document.getElementById(x);     // the folder button
    var z = document.getElementById(z);     // the folder display
    var box = ["resbox1", "resbox2", "resbox3", "resbox4"];
    var display = ["res1", "res2", "res3", "res4"];

    for (let i = 0; i < box.length; i++) { // hide all folders that are not selected
        document.getElementById(box[i]).style.background = "none";
        document.getElementById(display[i]).style.display = "none";
    }
    x.style.background = "#D5F5CD";
    z.style.display = "block";
}

//This function displays hidden elements for the resource_lib_4f00
function toggleDisplayRes_4f00(x, z) {
    var x = document.getElementById(x);     // the folder button
    var z = document.getElementById(z);     // the folder display
    var box = ["resbox4"];
    var display = ["res4"];

    for (let i = 0; i < box.length; i++) { // hide all folders that are not selected
        document.getElementById(box[i]).style.background = "none";
        document.getElementById(display[i]).style.display = "none";
    }
    x.style.background = "#D5F5CD";
    z.style.display = "block";
}

//This function displays hidden elements for the resource_lib_3p94 
function toggleDisplayRes_3p94(x, z) {
    var x = document.getElementById(x);     // the folder button
    var z = document.getElementById(z);     // the folder display
    var box = ["resbox1", "resbox2", "resbox3"];
    var display = ["res1", "res2", "res3"];

    for (let i = 0; i < box.length; i++) { // hide all folders that are not selected
        document.getElementById(box[i]).style.background = "none";
        document.getElementById(display[i]).style.display = "none";
    }
    x.style.background = "#D5F5CD";
    z.style.display = "block";
}

// Copy feedback
function copy_feedback(){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    var checkedOne = Array.prototype.slice.call(checkboxes).some(x => x.checked);
    if(checkedOne){
        alert("Folder is Copied.");
    }else{
        alert("Please Select a Folder.");
    }
}


function move_feedback(){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    var checkedOne = Array.prototype.slice.call(checkboxes).some(x => x.checked);
    if(checkedOne){
        alert("Folder is moved.");
    }else{
        alert("Please Select a Folder.");
    }
}

function trash_feedback(){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    var checkedOne = Array.prototype.slice.call(checkboxes).some(x => x.checked);
    if(checkedOne){
        alert("Folder is trashed.");
    }else{
        alert("Please Select a Folder.");
    }
}


function newFolder(){
    var popup = document.getElementById("newFolder_popup");
    var textbox = document.getElementById("textbox");
    textbox.value = "";
    popup.style.display = "block";
}

function createConfirm(){
    var popup = document.getElementById("newFolder_popup");
    popup.style.display = "none";
    alert("Folder is Created")
}

function closeForm(){
    var popup = document.getElementById("newFolder_popup");
    popup.style.display = "none";
}

function uploadFile(){
    var popup = document.getElementById("uploadFile_popup");
    popup.style.display = "block";
}

function submitFeedback(){
    alert("File is successfully uploaded")
}