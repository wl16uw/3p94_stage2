// Copy feedback
function copy_feedback(){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    var checkedOne = Array.prototype.slice.call(checkboxes).some(x => x.checked);
    if(checkedOne){
        alert("Folder is Copied");
    }else{
        alert("Please Select a Folder");
    }
}

function move_feedback(){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    var checkedOne = Array.prototype.slice.call(checkboxes).some(x => x.checked);
    if(checkedOne){
        alert("Folder is moved");
    }else{
        alert("Please Select a Folder");
    }
}

function delete_feedback(){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    var checkedOne = Array.prototype.slice.call(checkboxes).some(x => x.checked);
    if(checkedOne){
        alert("Folder is Deleted");
    }else{
        alert("Please Select a Folder");
    }
}

function save_feedback(){
    alert("Changes are Saved");
}

function cancel_feedback(){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for(var i=0; i<checkboxes.length; i++){
        checkboxes[i].checked = false;
    }
    alert("No Changes are Made")
}

function selectAllCheckbox(){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    if(document.getElementById("checkbox_subject").checked == true){
        for(var i=0; i<checkboxes.length; i++){
            checkboxes[i].checked = true;
        }        
    }else{
        for(var i=0; i<checkboxes.length; i++){
            checkboxes[i].checked = false;
        }
    }
}

function newAnnounce(){
    var popup = document.getElementById("newAnnounce_popup");
    popup.style.display = "block";
}

function createConfirm(){
    var popup = document.getElementById("newAnnounce_popup");
    popup.style.display = "none";
    alert("Announcement is Posted")
}

function closeForm(){
    var popup = document.getElementById("newAnnounce_popup");
    popup.style.display = "none";
}

function editAnnounce(){
    alert("You can start editting this announcement")
}